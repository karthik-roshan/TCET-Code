package javatest;
interface Roshan{
	String say(String message);
}
public class javatest {
public static void main(String args[])
{
	Roshan says=(message)->"hi "+message+"!";
	String greeting=says.say("how are you");
	System.out.print(greeting);
}
} 
