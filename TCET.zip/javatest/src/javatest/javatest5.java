package javatest;
import java.util.Arrays;
public class javatest5 {
    public static void main(String[] args) {
        int[] bucket = {0,0,0,0,1, 0, 2, 0, 3, 4, 0, 5,6,7,54};
        empty(bucket);
        System.out.println("Array after moving empty crates: " + Arrays.toString(bucket));
    }

    public static void empty(int[] bucket) {
        int n = bucket.length;
        int nonEmptyIndex = 0;
        for (int i = 0; i < n; i++) {
            if (bucket[i] != 0) {
                bucket[nonEmptyIndex] = bucket[i];
                nonEmptyIndex++;
            }
        }
        for (int i = nonEmptyIndex; i < n; i++) {
            bucket[i] = 0;
        }
    }
}

